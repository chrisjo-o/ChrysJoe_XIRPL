<?php

include "koneksi.php";

if(isset($_POST['simpan'])){

    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $eskul = $_POST['eskul'];
    $tanggal = $_POST['tanggal'];
    $status = $_POST['status'];
    $keterangan = $_POST['keterangan'];

    $stmt = $koneksi->prepare("INSERT INTO presensi_eskul(nama_peserta,kelas,ekstrakurikuler,tanggal,status,keterangan) VALUES (?,?,?,?,?,?)");

    $stmt->bind_param("ssssss",$nama,$kelas,$eskul,$tanggal,$status,$keterangan);

    if($stmt->execute()){
        echo "<script>
        alert('Data berhasil ditambahkan');
        window.location='index.php';
        </script>";
    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Tambah Data</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">

</head>

<body>

<nav class="navbar navbar-dark bg-primary">

<div class="container">

<span class="navbar-brand">

<i class="bi bi-calendar-check-fill"></i>

Sistem Presensi Ekstrakurikuler

</span>

</div>

</nav>

<div class="container mt-5">

<div class="card">

<div class="card-body">

<h3 class="mb-4">Tambah Data Presensi</h3>

<form method="POST">

<div class="row">

<div class="col-md-6 mb-3">

<label class="form-label">Nama Peserta</label>

<input type="text" name="nama" class="form-control" required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">Kelas</label>

<select name="kelas" class="form-select" required>
<option value="">-- Pilih Kelas --</option>
<option value="X RPL">X RPL</option>
<option value="X DKV">X DKV</option>
<option value="X AKL">X AKL</option>
<option value="XI RPL">XI RPL</option>
<option value="XI DKV">XI DKV</option>
<option value="XI AKL">XI AKL</option>
<option value="XII RPL">XII RPL</option>
<option value="XII DKV">XII DKV</option>
<option value="XII AKL">XII AKL</option>
</select>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">Ekstrakurikuler</label>

<input type="text" name="eskul" class="form-control" required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">Tanggal</label>

<input type="date" name="tanggal" class="form-control" required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">Status</label>

<select name="status" class="form-select">
<option value="Hadir">Hadir</option>
<option value="Izin">Izin</option>
<option value="Sakit">Sakit</option>
<option value="Alpha">Alpha</option>
</select>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">Keterangan</label>

<input type="text" name="keterangan" class="form-control">

</div>

</div>

<button type="submit" name="simpan" class="btn btn-primary">

<i class="bi bi-check-circle"></i>

Simpan

</button>

<a href="index.php" class="btn btn-secondary">

<i class="bi bi-arrow-left-circle"></i>

Kembali

</a>

</form>

</div>

</div>

<footer>

© 2026 Sistem Presensi Ekstrakurikuler

</footer>

</div>

</body>

</html>