<?php
include "koneksi.php";

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $stmt = $koneksi->prepare("DELETE FROM presensi_eskul WHERE id_presensi=?");
    $stmt->bind_param("i",$id);
    if($stmt->execute()){
        echo "<script>
        alert('Data berhasil dihapus');
        window.location='index.php';
        </script>";
    }else{
        echo "<script>
        alert('Data gagal dihapus');
        window.location='index.php';
        </script>";
    }
}else{

    header("Location:index.php");

}

?>