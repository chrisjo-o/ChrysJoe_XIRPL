<?php
include "koneksi.php";

$query = "SELECT * FROM presensi_eskul ORDER BY id_presensi DESC";
$data = $koneksi->query($query);

$total = $koneksi->query("SELECT COUNT(*) AS jumlah FROM presensi_eskul");
$jumlah = $total->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Presensi Ekstrakurikuler</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style.css">
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <span class="navbar-brand">
            <i class="bi bi-calendar-check-fill"></i>
            Sistem Presensi Ekstrakurikuler
        </span>
    </div>
</nav>

<div class="container mt-5">

    <div class="card">

        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center mb-4">

                <div>
                    <h3 class="mb-1">Data Presensi</h3>
                    <small class="text-muted">
                        Total Data : <?= $jumlah['jumlah']; ?>
                    </small>
                </div>

                <a href="tambah.php" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i>
                    Tambah Data
                </a>

            </div>

            <div class="row mb-3">

                <div class="col-md-4">

                    <input type="text" class="form-control" id="cari" placeholder="Cari peserta...">

                </div>

            </div>

            <div class="table-responsive">

                <table class="table table-bordered table-hover text-center align-middle" id="tabel">

                    <thead>

                        <tr>

                            <th>No</th>
                            <th>Nama Peserta</th>
                            <th>Kelas</th>
                            <th>Ekstrakurikuler</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php
                    $no = 1;

                    while($row = $data->fetch_assoc()){
                    ?>

                    <tr>

                        <td><?= $no++; ?></td>

                        <td><?= $row['nama_peserta']; ?></td>

                        <td><?= $row['kelas']; ?></td>

                        <td><?= $row['ekstrakurikuler']; ?></td>

                        <td><?= date("d-m-Y", strtotime($row['tanggal'])); ?></td>

                        <td>

                        <?php

                        if($row['status']=="Hadir"){
                            echo '<span class="badge bg-success">Hadir</span>';
                        }
                        elseif($row['status']=="Izin"){
                            echo '<span class="badge bg-warning text-dark">Izin</span>';
                        }
                        elseif($row['status']=="Sakit"){
                            echo '<span class="badge bg-primary">Sakit</span>';
                        }
                        else{
                            echo '<span class="badge bg-danger">Alpha</span>';
                        }

                        ?>

                        </td>

                        <td><?= $row['keterangan']; ?></td>

                        <td>

                            <a href="edit.php?id=<?= $row['id_presensi']; ?>" class="btn btn-warning btn-sm">
                                <i class="bi bi-pencil-square"></i>
                            </a>

                            <a href="hapus.php?id=<?= $row['id_presensi']; ?>"
                            class="btn btn-danger btn-sm"
                            onclick="return confirm('Yakin ingin menghapus data ini?')">

                                <i class="bi bi-trash-fill"></i>

                            </a>

                        </td>

                    </tr>

                    <?php
                    }
                    ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<script>

let cari = document.getElementById("cari");

cari.addEventListener("keyup", function(){

let filter = cari.value.toLowerCase();

let tr = document.querySelectorAll("#tabel tbody tr");

for(let i=0;i<tr.length;i++){

    let isi = tr[i].innerText.toLowerCase();

    if(isi.indexOf(filter)>-1){
        tr[i].style.display="";
    }else{
        tr[i].style.display="none";
    }

}

});

</script>

</body>
</html>