<?php
include "koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'];

$data = mysqli_query($koneksi, "SELECT * FROM presensi_eskul WHERE id_presensi='$id'");
$hasil = mysqli_fetch_assoc($data);

if (!$hasil) {
    echo "Data tidak ditemukan.";
    exit;
}

if (isset($_POST['simpan'])) {

    $nama = $_POST['nama_peserta'];
    $kelas = $_POST['kelas'];
    $ekstrakurikuler = $_POST['ekstrakurikuler'];
    $tanggal = $_POST['tanggal'];
    $status = $_POST['status'];
    $keterangan = $_POST['keterangan'];

    mysqli_query($koneksi, "UPDATE presensi_eskul SET
        nama_peserta='$nama',
        kelas='$kelas',
        ekstrakurikuler='$ekstrakurikuler',
        tanggal='$tanggal',
        status='$status',
        keterangan='$keterangan'
        WHERE id_presensi='$id'
    ");

    echo "<script>
            alert('Data berhasil diubah');
            window.location='index.php';
          </script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Presensi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">

    <div class="card">

        <div class="card-header bg-warning text-dark">
            <h3>Edit Data Presensi</h3>
        </div>

        <div class="card-body">

            <form method="post">

                <div class="mb-3">
                    <label class="form-label">Nama Peserta</label>
                    <input
                        type="text"
                        name="nama_peserta"
                        class="form-control"
                        value="<?= $hasil['nama_peserta']; ?>"
                        required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kelas</label>
                    <input
                        type="text"
                        name="kelas"
                        class="form-control"
                        value="<?= $hasil['kelas']; ?>"
                        required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Ekstrakurikuler</label>

                    <select name="ekstrakurikuler" class="form-select" required>

                        <option value="Pramuka"
                            <?= ($hasil['ekstrakurikuler']=="Pramuka") ? "selected" : ""; ?>>
                            Pramuka
                        </option>

                        <option value="PMR"
                            <?= ($hasil['ekstrakurikuler']=="PMR") ? "selected" : ""; ?>>
                            PMR
                        </option>

                        <option value="Paskibra"
                            <?= ($hasil['ekstrakurikuler']=="Paskibra") ? "selected" : ""; ?>>
                            Paskibra
                        </option>

                        <option value="Basket"
                            <?= ($hasil['ekstrakurikuler']=="Basket") ? "selected" : ""; ?>>
                            Basket
                        </option>

                        <option value="Futsal"
                            <?= ($hasil['ekstrakurikuler']=="Futsal") ? "selected" : ""; ?>>
                            Futsal
                        </option>

                        <option value="Voli"
                            <?= ($hasil['ekstrakurikuler']=="Voli") ? "selected" : ""; ?>>
                            Voli
                        </option>

                    </select>

                </div>

                <div class="mb-3">
                    <label class="form-label">Tanggal</label>

                    <input
                        type="date"
                        name="tanggal"
                        class="form-control"
                        value="<?= $hasil['tanggal']; ?>"
                        required>

                </div>

                <div class="mb-3">
                    <label class="form-label">Status</label>

                    <select name="status" class="form-select" required>

                        <option value="hadir"
                            <?= ($hasil['status']=="hadir") ? "selected" : ""; ?>>
                            Hadir
                        </option>

                        <option value="izin"
                            <?= ($hasil['status']=="izin") ? "selected" : ""; ?>>
                            Izin
                        </option>

                        <option value="sakit"
                            <?= ($hasil['status']=="sakit") ? "selected" : ""; ?>>
                            Sakit
                        </option>

                        <option value="alpha"
                            <?= ($hasil['status']=="alpha") ? "selected" : ""; ?>>
                            Alpha
                        </option>

                    </select>

                </div>

                <div class="mb-3">
                    <label class="form-label">Keterangan</label>

                    <textarea
                        name="keterangan"
                        class="form-control"
                        rows="3"><?= $hasil['keterangan']; ?></textarea>

                </div>

                <button type="submit" name="simpan" class="btn btn-warning">
                    Simpan Perubahan
                </button>

                <a href="index.php" class="btn btn-secondary">
                    Kembali
                </a>

            </form>

        </div>

    </div>

</div>

</body>
</html>